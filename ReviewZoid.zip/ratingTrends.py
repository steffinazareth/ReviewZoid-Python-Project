"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file extracts examines sentiment/rating trends over time. See functions below for more details.

This file is imported by main.py
"""

import matplotlib.pyplot as plt

def rating_trends_by_company(company, company_reviews_df, product_reviews_df):
    """
    Shows a plot of rating trends over time for a specific company

    :param company: string- company of interest
    :param company_reviews_df: dataframe holding company reviews
    :param product_reviews_df: dataframe holding product reviews
    :return: plot of trends of sentiment (proxy by rating) for a specific company
    """
    ## Examining in aggregation by Year-Month
    # merged_df = product_reviews_df.merge(company_reviews_df, on = 'Year-Month')
    # rating_df = merged_df[['Year-Month', 'Product_Rating', 'Company_Rating']]
    merged_df = product_reviews_df.merge(company_reviews_df, on = ['Year-Month', 'Company'])
    rating_df = merged_df[['Company', 'Year-Month', 'Product_Rating', 'Company_Rating']]
    rating_df = rating_df.groupby(['Company', 'Year-Month']).mean().reset_index()
    company_rating = rating_df[rating_df['Company'] == company]
    company_rating.groupby('Year-Month').mean().plot()
    plt.title(company)
    plt.ylabel("Rating")
    plt.savefig(company+"RatingTrends.png")
    plt.show()


def rating_trends_comparison(company_reviews_df, product_reviews_df, product_company):
    """
    Shows a plot of rating trends over time for all companies

    :param company_reviews_df: dataframe holding company reviews
    :param product_reviews_df: dataframe holding product reviews
    :param product_company: string to indicate examination by product reviews or company reviews for all companies
    :return: plot of trends of sentiment (proxy by rating) for either product or company reviews for all companies
    """
    merged_df = product_reviews_df.merge(company_reviews_df, on = ['Year-Month', 'Company'])
    rating_df = merged_df[['Company', 'Year-Month', 'Product_Rating', 'Company_Rating']]
    rating_comp = rating_df[['Company', 'Year-Month', product_company]]
    rating_comp = rating_comp.groupby(['Company', 'Year-Month']).mean().reset_index()

    rating_comp = rating_comp.set_index('Year-Month')
    rating_comp.set_index('Company', append=True).unstack()[product_company].plot()
    plt.title(product_company)
    plt.legend()
    plt.ylabel(product_company, fontsize=10)
    plt.xticks(rotation=45)
    plt.savefig('RatingTrendsComparison.png')
    plt.show()

