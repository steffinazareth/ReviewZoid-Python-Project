"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file generates summary statistics and visuals based off of the review data. See functions below for
more detail.

This file is imported by main.py
"""

#!/usr/bin/env python
# coding: utf-8
import matplotlib.pyplot as plt
from scipy import stats
import numpy as np
import topicAnalysis as ta

def dataLoad(company_df, product_df):
    """
    :param company_df: Dataframe of company reviews
    :param product_df: Dataframe of product reviews
    :return: Company dataframes and converted numpy arrays
    """
    df = ta.mergedDF(company_df, product_df)
    select_company_Dell = df.loc[df['Company'] == 'Dell']
    select_company_HP = df.loc[df['Company'] == 'HP']
    select_company_Lenovo = df.loc[df['Company'] == 'Lenovo']
    df2 = select_company_Dell[['Company','Rating']].to_numpy()
    df3 = select_company_HP[['Company','Rating']].to_numpy()
    return df, select_company_Dell, select_company_HP, select_company_Lenovo, df2, df3

def rmv_nan(arry):
    """
    :param arry: numpy array
    :return: numpy array with nans removed
    """
    return arry[~np.isnan(arry)]

def set_box_color(bp, color):
    """
    Sets boxplot colors

    :param bp: boxplot
    :param color: color code
    """
    plt.setp(bp['boxes'], color=color)
    plt.setp(bp['whiskers'], color=color)
    plt.setp(bp['caps'], color=color)
    plt.setp(bp['medians'], color=color)

def boxplots(company_df, product_df):
    """
    Renders boxplot of rating distributions for each company broken down by company/product reviews

    :param company_df: Company review dataframe
    :param product_df: Product review dataframe
    """
    companies = ['Dell', 'HP', 'Lenovo']
    company_rev = []
    prod_rev = []
    df = ta.mergedDF(company_df, product_df)
    for company in companies:
        company_review = df[(df['Company'] == company) & (df['Company/Product'] == "Company")]
        np_a = np.nan_to_num(company_review['Rating'].to_numpy()).astype('float64')
        co_np = rmv_nan(np_a)
        company_rev.append(co_np)

        prod_review = df[(df['Company'] == company) & (df['Company/Product'] == "Product")]
        np_prod = np.nan_to_num(prod_review['Rating'].to_numpy()).astype('float64')
        co_np_prod = rmv_nan(np_prod)
        prod_rev.append(co_np_prod)

    ## Referenced: https://stackoverflow.com/questions/16592222/matplotlib-group-boxplots
    ticks = companies
    company_rev = np.array(company_rev)
    prod_rev = np.array(prod_rev)

    plt.figure()

    bpl = plt.boxplot(company_rev, positions=np.array(range(len(company_rev))) * 2.0 - 0.4, sym='', widths=0.6)
    bpr = plt.boxplot(prod_rev, positions=np.array(range(len(prod_rev))) * 2.0 + 0.4, sym='', widths=0.6)
    set_box_color(bpl, '#D7191C')
    set_box_color(bpr, '#2C7BB6')

    plt.plot([], c='#D7191C', label='Company Reviews')
    plt.plot([], c='#2C7BB6', label='Product Reviews')
    plt.legend()

    plt.xticks(range(0, len(ticks) * 2, 2), ticks)
    plt.xlim(-2, len(ticks) * 2)
    plt.ylim(-1, 6)
    plt.title("Distribution of Ratings")
    plt.ylabel("Rating")
    plt.tight_layout()
    plt.savefig("RatingDistribution.png")
    plt.show()


def summary_stats(company_df, product_df):
    """
    Prints summary statistics for reviews for company and product reviews in combination for each company

    :param company_df: Company review dataframe
    :param product_df: Product review dataframe
    """

    df, select_company_Dell, select_company_HP, select_company_Lenovo, df2, df3 = dataLoad(company_df, product_df)
    #Preparing the data
    df4 = select_company_Lenovo[['Company','Rating']].to_numpy()

    #Ratings for comapnies in 2D Array
    out_arr_Dell = np.nan_to_num(df2)
    out_arr_HP = np.nan_to_num(df3)
    out_arr_Lenovo = np.nan_to_num(df4)
    #Only ratings for each company
    out_arr_Dell = out_arr_Dell[:,1]
    out_arr_HP = out_arr_HP[:,1]
    out_arr_Lenovo = out_arr_Lenovo[:,1]
    #Convert to float
    out_arr_Dell = out_arr_Dell.astype('float64')
    out_arr_HP = out_arr_HP.astype('float64')
    out_arr_Lenovo = out_arr_Lenovo.astype('float64')

    #Summary Statistics - Dell
    mean_arr_Dell = np.nanmean(out_arr_Dell)
    print("Mean of Dell's Ratings:", mean_arr_Dell)
    stand_dev_Dell = np.nanstd(out_arr_Dell)
    print("SD of Dell's Ratings:", stand_dev_Dell)
    mode_info_Dell = stats.mode(out_arr_Dell)
    print("Mode of Dell's Ratings:",mode_info_Dell[0])
    print()

    #Counting Positive and Negative Reviews of DELL
    unique, counts = np.unique(out_arr_Dell, return_counts=True)
    x = dict(zip(unique, counts))
    p1 = x[4.0]
    p2 = x[5.0]
    positive_Dell = p1 + p2
    print("Number of positive reviews of Dell:", positive_Dell)
    n1 = x[1.0]
    n2 = x[2.0]
    negative_Dell = n1 + n2
    print("Number of negative reviews of Dell:", negative_Dell)

    print("-------------------------------------------")
    #Summary Statistics - HP
    mean_arr_HP = np.nanmean(out_arr_HP)
    stand_dev_HP = np.nanstd(out_arr_HP)
    mode_info_HP = stats.mode(out_arr_HP)
    print("Mean of HP's Ratings:", mean_arr_HP)
    print("SD of HP's Ratings:", stand_dev_HP)
    print("Mode of HP's Ratings:",mode_info_HP[0])
    print()
    #Counting Positive and Negative Reviews of HP
    unique, counts = np.unique(out_arr_HP, return_counts=True)
    x = dict(zip(unique, counts))
    p1 = x[4.0]
    p2 = x[5.0]
    positive_HP = p1 + p2
    print("Number of positive reviews of HP:", positive_HP)
    n1 = x[1.0]
    n2 = x[2.0]
    negative_HP = n1 + n2
    print("Number of negative reviews of HP:", negative_HP)

    print("-------------------------------------------")

    #Summary Statistics - Lenovo
    mean_arr_Lenovo = np.nanmean(out_arr_Lenovo)
    stand_dev_Lenovo = np.nanstd(out_arr_Lenovo)
    mode_info_Lenovo = stats.mode(out_arr_Lenovo)
    print("Mean of Lenovo's Ratings:", mean_arr_Lenovo)
    print("SD of Lenovo's Ratings:", stand_dev_Lenovo)
    print("Mode of Lenovo's Ratings:",mode_info_Lenovo[0])
    print()
    # Counting Positive and Negative Reviews of Lenovo
    unique, counts = np.unique(out_arr_Lenovo, return_counts=True)
    x = dict(zip(unique, counts))
    p1 = x[4.0]
    p2 = x[5.0]
    positive_Lenovo = p1 + p2
    print("Number of positive reviews of Lenovo:", positive_Lenovo)
    n1 = x[1.0]
    n2 = x[2.0]
    negative_Lenovo = n1 + n2
    print("Number of negative reviews of Lenovo:", negative_Lenovo)

    print("-------------------------------------------")

    # data to plot
    n_groups = 3
    pos_reviews = (positive_Dell,positive_HP,positive_Lenovo)
    neg_reviews = (negative_Dell,negative_HP,negative_Lenovo)
    # create plot
    index = np.arange(n_groups)
    bar_width = 0.35
    opacity = 0.8

    rects1 = plt.bar(index, pos_reviews, bar_width,
    alpha=opacity,
    color='b',
    label='Positive Reviews')

    rects2 = plt.bar(index + bar_width, neg_reviews, bar_width,
    alpha=opacity,
    color='g',
    label='Negative Reviews')

    plt.xlabel('Company')
    plt.ylabel('Reviews')
    plt.title('Positive and Negative Reviews by Company')
    plt.xticks(index + bar_width, ('Dell', 'HP', 'Lenovo'))
    plt.legend()
    plt.tight_layout()
    plt.show()
