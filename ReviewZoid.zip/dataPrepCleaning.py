"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file cleans the review data, joins product and company reviews, and does additional filtering to prep the data.

This file is imported by main.py
"""

import pandas as pd
import datetime

def dataLoadPrep():
    """
    Loading, consolidating, and data cleanup.
    Will look for newly scraped data; otherwise, will fallback on pre-scraped data.

    :return: dataframes of review data for both company reviews and product reviews
    """

    ### Looking for newly scraped data
    try:
        bestbuy_dell = pd.read_csv("Updated_BestBuyReviews_Dell.csv")
        bestbuy_lenovo = pd.read_csv("Updated_BestBuyReviewsLenovo.csv")
        bestbuy_hp = pd.read_csv("Updated_BestBuyReviews_HP.csv")
        costco_dell = pd.read_csv("Updated_CostcoReviews_Dell.csv", encoding='cp1252')
        costco_lenovo = pd.read_csv("Updated_CostcoReviews_Lenovo.csv", encoding='cp1252')
        costco_hp = pd.read_csv("Updated_CostcoReviews_HP.csv", encoding='cp1252')
        trustpilot_dell = pd.read_csv("Updated_TrustPilot_Dell.csv")
        trustpilot_hp = pd.read_csv("Updated_TrustPilot_HP.csv")
        trustpilot_lenovo = pd.read_csv("Updated_TrustPilot_Lenovo.csv")
        consumeraffairs_dell = pd.read_csv("Updated_ConsumerAffairs_Dell.csv")
        consumeraffairs_HP = pd.read_csv("Updated_ConsumerAffairs_HP.csv")
        consumeraffairs_Lenovo = pd.read_csv("Updated_ConsumerAffairs_Lenovo.csv")
        consumeraffairs = pd.concat([consumeraffairs_Lenovo, consumeraffairs_dell, consumeraffairs_HP]).drop_duplicates()
        trustpilot = pd.concat([trustpilot_hp, trustpilot_dell, trustpilot_lenovo])

    ### Otherwise, use pre-scraped data.
    except:
        print("Completed set of new data not found... Using pre-scraped data...")
        ## Loading data and adding company labels
        bestbuy_dell = pd.read_csv("BestBuyReviews_Dell.csv")
        bestbuy_lenovo = pd.read_csv("BestBuyReviews_Lenovo.csv")
        bestbuy_hp = pd.read_csv("BestBuyReviews_HP.csv")
        costco_dell = pd.read_csv("CostcoReviews_Dell.csv", encoding='cp1252')
        costco_lenovo = pd.read_csv("CostcoReviews_Lenovo.csv", encoding='cp1252')
        costco_hp = pd.read_csv("CostcoReviews_HP.csv", encoding='cp1252')
        trustpilot = pd.read_csv("TrustPilot.csv")
        consumeraffairs_dell = pd.read_csv("ConsumerAffairs_Dell.csv")
        consumeraffairs_HP = pd.read_csv("ConsumerAffairsLenovoHP.csv")
        consumeraffairs = pd.concat([consumeraffairs_dell, consumeraffairs_HP]).drop_duplicates()

    bestbuy_dell['Company'] = "Dell"
    bestbuy_lenovo['Company'] = "Lenovo"
    bestbuy_hp['Company'] = "HP"

    costco_dell['Company'] = "Dell"
    costco_lenovo['Company'] = "Lenovo"
    costco_hp['Company'] = "HP"
    ####

    ## Combining relevant tables and adding source labels, resulting in two main tables:
    ## Company reviews and Product Reviews
    bb = [bestbuy_dell, bestbuy_lenovo, bestbuy_hp]
    bestbuy_df = pd.concat(bb).drop_duplicates()
    bestbuy_df['Source'] = "BestBuy"
    bestbuy_df = bestbuy_df.drop('Review_Title', axis='columns')

    cc = [costco_hp, costco_dell, costco_lenovo]
    costco_df = pd.concat(cc).drop_duplicates()
    costco_df['Source'] = "Costco"
    product_reviews_df = pd.concat([costco_df, bestbuy_df])
    company_reviews_df = pd.concat([trustpilot, consumeraffairs])

    ## Cleaning dates
    date_cleanup(product_reviews_df, 'Date_Posted')
    date_cleanup(company_reviews_df, 'Date')
    createDateTimeCols(product_reviews_df, 'Date_Posted')
    createDateTimeCols(company_reviews_df, 'Date')

    # Looking only at reviews from 2018 to present
    product_reviews_df = product_reviews_df[product_reviews_df['Year'] > 2017]
    product_reviews_df = product_reviews_df.rename(columns={'Rating': 'Product_Rating'})
    company_reviews_df = company_reviews_df[company_reviews_df['Year'] > 2017]
    company_reviews_df = company_reviews_df.rename(columns={'Rating': 'Company_Rating'})
    return product_reviews_df.drop_duplicates(), company_reviews_df.drop_duplicates()

def date_cleanup(df, date_col):
    """
    Cleans and converts date column to single datetime format

    :param df: dataframe of reviews
    :param date_col: column header for date
    """
    for idx, row in df.iterrows():
        date = row[date_col]
        try:
            newDate = datetime.datetime.strptime(date, '%b %d, %Y').strftime('%m-%d-%Y')
            df.at[idx, date_col] = newDate
        except:
            try:
                newDate = datetime.datetime.strptime(date, '%m/%d/%Y').strftime('%m-%d-%Y')
                df.at[idx, date_col] = newDate
            except:
                try:
                    newDate = datetime.datetime.strptime(date, '%Y-%m-%d').strftime('%m-%d-%Y')
                    df.at[idx, date_col] = newDate
                except:
                    try:
                        newDate = datetime.datetime.strptime(date, '%b. %d, %Y').strftime('%m-%d-%Y')
                        df.at[idx, date_col] = newDate
                    except:
                        pass

def createDateTimeCols(df, date_col):
    """
    Breaks out date into year, month, and year-month columns for use in other analysis

    :param df: dataframe of reviews
    :param date_col: column header for date
    """
    df[date_col] = pd.to_datetime(df[date_col])
    df['Year'] = pd.DatetimeIndex(df[date_col]).year
    df['Month'] = pd.DatetimeIndex(df[date_col]).month
    df['Year-Month'] = df[date_col].dt.strftime('%Y-%m')

