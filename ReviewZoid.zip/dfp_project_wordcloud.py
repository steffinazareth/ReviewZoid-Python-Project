# -*- coding: utf-8 -*-

"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file renders word clouds based off of the Google news data

This file is imported by getNews.py
"""

import pandas as pd
from wordcloud import WordCloud, STOPWORDS 
import matplotlib.pyplot as plt 

def wordcloud_generator(filename):
    """
    Here, we take the Google news summary file and generate wordclouds based on the summary of the article.
    The intention is to give a quick snapshot of the most talked about terms/topics in recent news.

    :param filename: Google news filename output file
    :return: Saved .pngs of word clouds for each company of interest
    """
    data=pd.read_csv(filename)

    stopwords = set(STOPWORDS)
    stopwords.add('laptop')
    stopwords.add('Dell')
    stopwords.add('HP')
    stopwords.add('Lenovo')

    company_names=data['Company'].unique()

    for x in range(len(company_names)):
        all_words = ''  #string which will contain each word in the summary column for each company
        stopwords.add(company_names[x])
        data_temp=data[data['Company']==company_names[x]]
        for row in data_temp['Summary']:
            row_lowercase=str(row).lower()
            words=row_lowercase.split(' ')
            for i in range(len(words)):
                all_words += " "+words[i]
        wordcloud = WordCloud(width = 800, height = 800,
                    background_color ='white',
                    stopwords = stopwords,
                    min_font_size = 10).generate(all_words)
        plt.figure(figsize = (8, 8), facecolor = None)   #plot the WordCloud image
        plt.imshow(wordcloud)
        plt.title(company_names[x], fontsize=40)
        plt.axis("off")
        plt.tight_layout(pad = 0)
        plt.savefig(company_names[x] + '_wordcloud' + '.png')
        plt.show()