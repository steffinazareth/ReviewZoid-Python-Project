"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file scrapes TrustPilot.com

This file is imported by main.py
"""

from bs4 import BeautifulSoup
from selenium import webdriver
import csv
import time

DRIVER_PATH = 'chromedriver.exe'
BASE_URL = 'https://www.bestbuy.com'
options = webdriver.ChromeOptions()
options.add_argument('--ignore-certificate-errors')
options.add_argument('--ignore-ssl-errors')
options.add_argument('--ignore-certificate-errors-spki-list')
options.set_capability("acceptInsecureCerts", True)

def getData(URL):
    """
    :param URL: URL of site to scrape
    :return: html of site
    """
    driver = webdriver.Chrome(executable_path=DRIVER_PATH, options = options)
    driver.get(URL)
    time.sleep(1)
    html = BeautifulSoup(driver.page_source, "html.parser")
    driver.close()
    return html

def scrapeTP(company):
    """
    Scrapes TrustPilot for company of interest

    :param company: Company to scrape
    :return: CSV file of scraped data
    """
    if company == "Dell":
        query = {'www.dell.com': ('Dell', 54)}
    elif company == "HP":
        query = {'hp.com':('HP', 60)}
    else:
        query = {'www.lenovo.com':('Lenovo', 17)}

    csv_name = "Updated_TrustPilot_" + company + ".csv"
    with open(csv_name, "w", newline="", encoding='utf-8') as outfile:
        writer = csv.DictWriter(outfile, fieldnames=["Company", "Date", "Rating", "Content"])
        writer.writeheader()
        counter = 0

        for q in query:
            for page in range(query[q][1]):
                URL = "https://www.trustpilot.com/review/"+q+"?page="+str(page+1)
                print(URL)
                html = getData(URL)

                for card in html.find_all("div", {"class":"review-card"}):
                    d = {}
                    try:
                        rating = card.find("div", {"class":"star-rating"}).find("img")["alt"].split()[0]
                    except:
                        rating = ""
                    try:
                        date = card.find("span", {"class":"trigger"}).find("time")["datetime"].split("T")[0]
                    except:
                        date = ""
                    try:
                        content = card.find("p", {"class":"review-content__text"}).text.strip()
                    except:
                        content = ""
                    d["Company"] = query[q][0]
                    d["Rating"] = rating
                    d["Date"] = date
                    d["Content"] = content
                    writer.writerow(d)
                    print(counter)
                    counter += 1


