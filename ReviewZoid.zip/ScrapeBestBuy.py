"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file scrapes BestBuy.com

This file is imported by main.py
"""

from bs4 import BeautifulSoup
from selenium import webdriver
import csv
import time

DRIVER_PATH = 'chromedriver.exe'
BASE_URL = 'https://www.bestbuy.com'
options = webdriver.ChromeOptions()
options.add_argument('--ignore-certificate-errors')
options.add_argument('--ignore-ssl-errors')
options.add_argument('--ignore-certificate-errors-spki-list')
options.set_capability("acceptInsecureCerts", True)

def getData(URL):
    """
    :param URL: URL of site to scrape
    :return: html of site
    """
    driver = webdriver.Chrome(executable_path=DRIVER_PATH, options = options)
    driver.get(URL)
    time.sleep(1)
    html = BeautifulSoup(driver.page_source, "html.parser")
    driver.close()
    return html

def checkNextPage(review_html):
    """
    Checks to see if pagination exists

    :param review_html: HTML of site
    :return: Boolean based on if next page icon is found
    """
    nextpage = review_html.find("li", {"class": "page next"})
    if nextpage is not None:
        nextpage = True
    else:
        nextpage = False
    return nextpage

def output(rev_content, prod_title, price, prod_url, writer):
    """
    Adds a row to output csv file

    :param rev_content: HTML of review content
    :param prod_title: product title
    :param price: price of product
    :param prod_url: product URL
    :param writer: dict writer object
    """
    rating = rev_content.find('p', {"class": "sr-only"}).text.split()[1]
    review_title = rev_content.find('h4', {'class': 'review-title'}).text
    date_posted = rev_content.find("time", {"class": "submission-date"})['title']
    review_content = rev_content.find("p", {"class": "pre-white-space"}).text
    d = {}
    d['Product_Title'] = prod_title
    d['Price'] = price
    d['ProductURL'] = prod_url
    d['Rating'] = rating
    d['Review_Title'] = review_title
    d['Date_Posted'] = " ".join(date_posted.split()[:3])
    d['Review_Content'] = review_content
    writer.writerow(d)

def scrapeBestBuy(company):
    """
    Scrapes BestBuy.com for company of interest

    :param company: Company to scrape
    :return: CSV file of scraped data
    """
    url_lst = ['https://www.bestbuy.com/site/searchpage.jsp?cp=1&id=pcat17071&st=dell%20laptop',
               'https://www.bestbuy.com/site/searchpage.jsp?cp=1&id=pcat17071&st=hp%20laptop',
               'https://www.bestbuy.com/site/searchpage.jsp?cp=1&id=pcat17071&st=lenovo%20laptop']

    if company == "HP":
        URL = url_lst[1]
    elif company == "Dell":
        URL = url_lst[0]
    else:
        URL = url_lst[2]
    html = getData(URL)

    max_page = [x.text for x in html.find_all('li', {'class':'page-item'})][-1]
    main_page = 1
    counter = 0

    csv_name = "Updated_BestBuyReviews_" + company + ".csv"

    with open(csv_name, "w", newline="", encoding='utf-8') as outfile:
        writer = csv.DictWriter(outfile, fieldnames=["Product_Title", "Price", "ProductURL",
                                                     "Rating", "Review_Title", "Date_Posted",
                                                     "Review_Content"])
        writer.writeheader()

        while main_page <= int(max_page):
            print("Page: ", main_page)
            for prod in html.find_all('li', {'class':'sku-item'}):
                try:
                    prod_title = prod.find('h4', {'class':'sku-header'}).text
                except:
                    prod_title = ""
                try:
                    price = prod.find('div', {'class':'priceView-hero-price priceView-customer-price'}).find('span').text
                except:
                    price = 0
                prod_url_ext = prod.find('li', {"class":"ugc-stat customer-review-stats"}).find('a', href = True)['href']
                prod_url = BASE_URL + prod_url_ext

                print("Product URL: ", prod_url)
                inf = getData(prod_url)
                try:
                    all_rev_link = inf.find("div", {"class":"see-all-reviews-button-container"}).find('a', href = True)['href']
                except:
                    continue

                review_html = getData(BASE_URL + all_rev_link + '&page=1')
                nextpage = True
                page = 1

                ### If pagination still exists, click on next page and continue scraping
                while nextpage:
                    nextpage = checkNextPage(review_html)
                    for rev_content in review_html.find_all("div", {"class": "review-item-content"}):
                        output(rev_content, prod_title, price, prod_url, writer)
                        print("Review count: ", counter)
                        counter += 1
                    page += 1
                    if nextpage:
                        review_html = getData(BASE_URL + all_rev_link + '&page=' + str(page))

            main_page += 1
            URL = "https://www.bestbuy.com/site/searchpage.jsp?cp="+str(main_page)+"&id=pcat17071&st=hp%20laptop"
            html = getData(URL)
