"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file scrapes ConsumerAffairs.com

This file is imported by main.py
"""

from bs4 import BeautifulSoup
from selenium import webdriver
import csv
import time

DRIVER_PATH = 'chromedriver.exe'
BASE_URL = 'https://www.bestbuy.com'
options = webdriver.ChromeOptions()
options.add_argument('--ignore-certificate-errors')
options.add_argument('--ignore-ssl-errors')
options.add_argument('--ignore-certificate-errors-spki-list')
options.set_capability("acceptInsecureCerts", True)

def getData(URL):
    """
    :param URL: URL of site to scrape
    :return: html of site
    """
    driver = webdriver.Chrome(executable_path=DRIVER_PATH, options = options)
    driver.get(URL)
    time.sleep(1)
    html = BeautifulSoup(driver.page_source, "html.parser")
    driver.close()
    return html

def scrapeCA(company):
    """
    Scrapes Consumer Affairs for company of interest

    :param company: Company to scrape
    :return: CSV file of scraped data
    """
    if company == "Dell":
        query = {'dell_lap':('Dell', 57)}
    elif company == "HP":
        query = {'hewlett_packard_computers':('HP', 59)}
    else:
        query = {'lenovo':('Lenovo', 45)}

    csv_name = "Updated_ConsumerAffairs_" + company + ".csv"
    with open(csv_name, "w", newline="", encoding='utf-8') as outfile:
        writer = csv.DictWriter(outfile, fieldnames=["Company", "Rating", "Date", "Content"])
        writer.writeheader()
        counter = 0
        for q in query:
            for page in range(1, query[q][1]+1):
                URL = "https://www.consumeraffairs.com/computers/"+q+".html?page=" + str(page) + "#sort=top_reviews&filter=none"
                html = getData(URL)
                print(URL)
                try:
                    html.find("div", {"id": "reviews-container"}).find_all("div", {"class": "rvw js-rvw"})
                except:
                    URL = "https://www.consumeraffairs.com/computers/" + q + ".htm?page=" + str(
                        page) + "#sort=top_reviews&filter=none"
                    html = getData(URL)
                    print(URL)

                for x in html.find("div", {"id":"reviews-container"}).find_all("div", {"class":"rvw js-rvw"}):
                    d = {}
                    try:
                        rating = x.find("meta", {"itemprop":"ratingValue"})["content"]
                    except:
                        rating = ""

                    try:
                        date = x.find("span", {"class":"ca-txt-cpt"}).text.split(":")[-1].strip()
                    except:
                        date = ""

                    try:
                        content = "".join([x.text for x in x.find("div", {"class":"rvw-bd"}).find_all('p')])
                    except:
                        content = ""

                    company = query[q][0]
                    d['Company'] = company
                    d['Rating'] = rating
                    d['Date'] = date
                    d['Content'] = content
                    writer.writerow(d)
                    print(counter)
                    counter += 1

