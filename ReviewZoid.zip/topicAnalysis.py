"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file extracts topics from the review data using the LDA methods. See below for specific details
on the functions used.

This file is imported by main.py
"""

import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation as LDA
import re

def removeCommonWords(string):
    """
    Removes common words and punctuation that would be meaningless from reviews
    (excluding stopwords, which is removed during the LDA process)
    i.e. laptop, computer
    In topic extraction, these words are meaningless because we know they are
    reviewing laptops and computers; we also remove common adjective words like "good" and "great" because
    we are interested in topics. We break down the data into positive/negative reviews later on, so these
    adjectives do not provide meaningful information.

    :param string: String to remove words from
    :return: Cleaned string of text
    """
    string = re.sub(r'[^\w\s]', ' ', string)

    words = ['laptop', 'computer', 'laptops', 'computers', 'notebook', 'notebooks', 'hp', 'dell', 'lenovo',
             'costco', 'best buy', 'bestbuy', 'use', 'great', 'does', 'need', 'don', 'good', 'best', 'buy',
             'bought', 'like', 'love', 'hate', 'really', 'use', 'told', 'just', 'did', 'don', 'work', 'got',
             'nice', 'far']
    return ' '.join([x for x in string.split() if x.lower() not in words])

def mergedDF(company_reviews_df, product_reviews_df):
    """
    Creates merged dataframe of cleaned, combined review data

    :param company_reviews_df: Company reviews dataframe
    :param product_reviews_df: Product reviews dataframe
    :return: Dataframe of merged review data
    """
    company_reviews_df['Company/Product'] = 'Company'
    product_reviews_df['Company/Product'] = 'Product'
    product_reviews_df = product_reviews_df[['Date_Posted', 'Review_Content', 'Company', 'Year',
                                             'Year-Month', 'Month', 'Product_Rating', 'Company/Product']]
    product_reviews_df = product_reviews_df.rename(columns={'Date_Posted': 'Date', 'Review_Content': 'Content',
                                                            'Product_Rating': 'Rating'})
    company_reviews_df = company_reviews_df.rename(columns={'Company_Rating': 'Rating'})
    merged_df = pd.concat([product_reviews_df, company_reviews_df])

    merged_df = merged_df[:].dropna(subset=['Content'])
    return merged_df

def topicExtraction(merged_df):
    """
    Uses LDA methodology to extract main topics from each review and adds it to the dataframe
    Referenced: https://towardsdatascience.com/end-to-end-topic-modeling-in-python-latent-dirichlet-allocation-lda-35ce4ed6b3e0

    :param merged_df: Dataframe of merged reviews
    :return: Merged dataframe of all company and product reviews with topics extracted
    """
    count_vectorizer = CountVectorizer(stop_words='english')
    count_data = count_vectorizer.fit_transform(merged_df['Content'])

    number_topics = 1
    number_words = 10
    lda = LDA(n_components=number_topics, n_jobs=-1)
    lda.fit(count_data)
    return found_topics(lda, count_vectorizer, number_words)


def found_topics(model, count_vectorizer, n_top_words):
    words = count_vectorizer.get_feature_names()
    top = []
    for topic_idx, topic in enumerate(model.components_):
        top = [words[i] for i in topic.argsort()[:-n_top_words - 1:-1]]
    return top

def analyzingTopics(company_reviews_df, product_reviews_df, input):
    """
    Returns top 10 found keywords/topics for given population of interest (all positive, negative,
    all companies, product reviews, or product reviews)
    Note that rating is taken as a proxy for sentiment: ratings of 1 and 2 are negative, and ratings
    of 4 or 5 are positive

    :param company_reviews_df:
    :param product_reviews_df:
    :param input:
    :return:
    """
    print()
    merged_df = mergedDF(company_reviews_df, product_reviews_df)
    merged_df['Content'] = merged_df['Content'].apply(lambda x: removeCommonWords(x))
    merged_df['Topics'] = ''

    positive_sentiment = merged_df[merged_df['Rating'] > 3]
    negative_sentiment = merged_df[merged_df['Rating'] < 3]
    if input == 'positive':
        topics = topicExtraction(positive_sentiment)
        print('Positive:')
        print(topics)
    elif input == 'negative':
        topics = topicExtraction(negative_sentiment)
        print('Negative:')
        print(topics)
    elif input == 'product':
        pos = topicExtraction(positive_sentiment[positive_sentiment['Company/Product'] == 'Product'])
        neg = topicExtraction(negative_sentiment[negative_sentiment['Company/Product'] == 'Product'])
        print('Product Reviews Only:')
        print('Positive:')
        print(pos)
        print('Negative:')
        print(neg)
    elif input == 'company':
        pos = topicExtraction(positive_sentiment[positive_sentiment['Company/Product'] == 'Company'])
        neg = topicExtraction(negative_sentiment[negative_sentiment['Company/Product'] == 'Company'])
        print('Company Reviews Only:')
        print('Positive:')
        print(pos)
        print('Negative:')
        print(neg)
    elif input == 'Dell':
        dell_topics_p = topicExtraction(positive_sentiment[positive_sentiment['Company'] == 'Dell'])
        dell_topics_n = topicExtraction(negative_sentiment[negative_sentiment['Company'] == 'Dell'])
        print("Review topics for Dell:")
        print("Positive: ", dell_topics_p)
        print("Negative: ", dell_topics_n)
    elif input == 'Lenovo':
        lenovo_topics_p = topicExtraction(positive_sentiment[positive_sentiment['Company'] == 'Lenovo'])
        lenovo_topics_n = topicExtraction(negative_sentiment[negative_sentiment['Company'] == 'Lenovo'])
        print("Review topics for Lenovo:")
        print("Positive: ", lenovo_topics_p)
        print("Negative: ", lenovo_topics_n)
    elif input == 'Hp':
        hp_topics_p = topicExtraction(positive_sentiment[positive_sentiment['Company'] == 'HP'])
        hp_topics_n = topicExtraction(negative_sentiment[negative_sentiment['Company'] == 'HP'])
        print("Review topics for HP:")
        print("Positive: ", hp_topics_p)
        print("Negative: ", hp_topics_n)
    else:
        dell_topics_p = topicExtraction(positive_sentiment[positive_sentiment['Company'] == 'Dell'])
        hp_topics_p = topicExtraction(positive_sentiment[positive_sentiment['Company'] == 'HP'])
        lenovo_topics_p = topicExtraction(positive_sentiment[positive_sentiment['Company'] == 'Lenovo'])
        print("*********************************************")
        print("Positive:")
        print("Dell: ", dell_topics_p)
        print("--------------------------------")
        print("HP: ", hp_topics_p)
        print("--------------------------------")
        print("Lenovo: ", lenovo_topics_p)

        dell_topics_n = topicExtraction(negative_sentiment[negative_sentiment['Company'] == 'Dell'])
        hp_topics_n = topicExtraction(negative_sentiment[negative_sentiment['Company'] == 'HP'])
        lenovo_topics_n = topicExtraction(negative_sentiment[negative_sentiment['Company'] == 'Lenovo'])
        print("*********************************************")
        print("Negative:")
        print("Dell: ", dell_topics_n)
        print("--------------------------------")
        print("HP: ", hp_topics_n)
        print("--------------------------------")
        print("Lenovo: ", lenovo_topics_n)




