"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file pulls from the FinnHub API to grab financial metrics for output and analysis..

This file is imported by main.py
"""

import requests
import csv
import pandas as pd
import matplotlib.pyplot as plt

API_KEY = "btju5df48v6vivbns52g"

first_url_metrics = 'https://finnhub.io/api/v1/stock/metric?symbol='
end_url_metrics = '&metric=all&token='+API_KEY

first_url_stock = 'https://finnhub.io/api/v1/quote?symbol='
end_url_stock = '&token=' + API_KEY

def getMetrics(symbol, metric_input, preloaded):
    """
    Connects to FinnHub to pull down financial data

    :param symbol: List containing stock symbols of interest
    :return: Outputs CSV file containing financial information of stock symbols
    """

    with open("FinancialMetricsComparison.csv", "w", newline="") as outfile:
        writer = csv.DictWriter(outfile, fieldnames=['Company', 'FCF_PerShareTTM', 'GrossMargin_Annual',
                                                     'GrossMargin_5Y', 'FCF_TTM', '52_Week_High',
                                                     '52_Week_Low', 'Metric', 'Period',
                                                     'Value'])
        writer.writeheader()

        full_df = pd.DataFrame()

        if int(preloaded) == 2:
            for sym in symbol:
                lnk = first_url_metrics + sym + end_url_metrics
                r = requests.get(lnk)
                data = r.json()

                counter = 0
                if len(data['metric']) == 0:
                    print("Sorry, no financial metrics found for "+sym +". Please check your stock symbols.")
                    counter+=1
                    if counter == len(symbol):
                        return "Invalid"
                    else:
                        continue
                metrics = ['salesPerShare', 'totalDebtToEquity', 'grossMargin']
                fifty_week_high = data['metric']['52WeekHigh']
                fifty_week_low = data['metric']['52WeekLow']

                for m in metrics:
                    for inf in data['series']['annual'][m]:
                        d = {}
                        d['Metric'] = m
                        d['Period'] = inf['period']
                        d['Value'] = inf['v']
                        d['Company'] = data['symbol']
                        d['FCF_PerShareTTM'] = data['metric']['freeCashFlowPerShareTTM']
                        d['GrossMargin_Annual'] = data['metric']['grossMarginAnnual']
                        d['GrossMargin_5Y'] = data['metric']['grossMargin5Y']
                        d['FCF_TTM'] = data['metric']['freeCashFlowTTM']
                        d['52_Week_High'] = fifty_week_high
                        d['52_Week_Low'] = fifty_week_low
                        writer.writerow(d)
                        full_df = full_df.append(d, ignore_index=True)
        else:
            full_df = pd.read_csv("FinancialMetricsComparison_DellHPQ.csv")
        subdf = full_df[full_df['Metric'] == metric_input]
        subdf['Year'] = pd.DatetimeIndex(subdf['Period']).year
        subdf['Year'] = pd.to_datetime(subdf['Year'], format='%Y')
        subdf = subdf[['Company', 'Year', 'Value']]
        subdf = subdf.set_index('Year')

        subdf.set_index('Company', append=True).unstack()['Value'].plot()
        plt.title(metric_input)
        plt.ylabel(metric_input + ' ($)', fontsize=10)
        plt.savefig(metric_input + '.png')
        plt.show()


    return "Success"
