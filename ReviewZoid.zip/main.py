"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is the main file that runs the app. It imports all of the sub-files as modules:
dataPrepCleaning
ratingTrends: analyzing sentiment/rating trends over time
topicAnalysis: extracting topics from the review data
financialMetricsScrape: pulls and creates output and visuals for financial data (connects to FinnHub API)
getNews: pulls and creates csv summary of top Google news stories and generates word cloud
ScrapeBestBuy: scrapes BestBuy.com
scrapeCostco: scrapes Costco.com
scrapeTrustPilot: scrapes TrustPilot.com
scrapeConsumerAffairs: scrapes ConsumerAffairs.com
SummaryStats: generates summary statistics based on the review data
"""


import dataPrepCleaning as dp
import ratingTrends as rt
import topicAnalysis as ta
import financialMetricsScrape as financials
import getNews as news
import ScrapeBestBuy as scrapeBB
import scrapeCostco as scrapeCC
import scrapeTrustPilot as scrapeTP
import scrapeConsumerAffairs as scrapeCA
import SummaryStats as sumStats

def displayMenu():
    """
    Renders the main display menu upon launch
    """
    print("################################################################################################################")
    print("Welcome to ReviewZoid!")
    print("Note: For the purposes of this prototype, the data prepared is for laptops from Dell, HP, and Lenovo.")
    print("------------------------------------------")
    print()
    print("Please select from the menu options below:")
    print()
    print("\t1. Scrape New Data ***Not Recommended***")
    print("\tExplore options to scrape down new data. Otherwise, other options will utilize pre-loaded data."+
          "\n\tNew data pull can take several hours (ranging from 2-15 hours)."+
          "\n\t**Note that review analysis options will utilize pre-scraped data if complete set of new data not found "
            + "\n\tgiven necessity for review volume**")
    print()
    print("\t2. Analyze Review Data")
    print("\tExamine review data scraped from Best Buy, Costco, Trust Pilot, and Consumer Affairs for "+
          "\n\tsentiment trends and key topics. Analysis limited to reviews in the past 2 years.")
    print()
    print("\t3. View Financial Metrics")
    print("\tCreate output file and plot with financial metrics to compare for companies of interest (based on stock symbol)"+
           "\n\tNote: can explore companies outside of targeted companies.")
    print()
    print("\t4. What's in the News?")
    print("\tCreate output file with a summary of top news stories for company of interest.")
    print()
    print("\t5. Output review data")
    print("\tCreate output file with cleaned, consolidated review data.")
    print()
    print("################################################################################################################")
    while True:
        valid = [0, 1, 2, 3, 4, 5]
        print()
        user_select = input("Please enter your selection (1, 2, 3, 4, 5, 0 to exit): ")
        if int(user_select) in valid:
            return int(user_select)
        else:
            print("Invalid selection. Please try again.")

def menuReroute(selection):
    """
    Renders user to submenus based on the main menu selection

    :param selection: Based on the user input from the main menu
    """
    if selection == 1:
        second_sel = scrapeMenu()
        while True:
            if second_sel == 5:
                break
            site, company = scrapeSubMenu(second_sel)
            if site == None and company == None:
                break
            if site == "BestBuy":
                scrapeBB.scrapeBestBuy(company)
            elif site == "Costco":
                scrapeCC.scrapeCostco(company)
            elif site == "TrustPilot":
                scrapeTP.scrapeTP(company)
            elif site == "ConsumerAffairs":
                scrapeCA.scrapeCA(company)
    elif selection == 2:
        print("Loading data... May take a few moments...")
        product_reviews_df, company_reviews_df = dp.dataLoadPrep()
        while True:
            second_sel = reviewMenu()
            if second_sel == 8:
                break
            if second_sel == 1:
                company = reviewSubMenu(1)
                rt.rating_trends_by_company(company, company_reviews_df, product_reviews_df)
            elif second_sel == 2:
                company_product = reviewSubMenu(2)
                if company_product == "Product":
                    rt.rating_trends_comparison(company_reviews_df, product_reviews_df, 'Product_Rating')
                else:
                    rt.rating_trends_comparison(company_reviews_df, product_reviews_df, 'Company_Rating')
            elif second_sel == 3:
                company = reviewSubMenu(3)
                ta.analyzingTopics(company_reviews_df, product_reviews_df, company)
            elif second_sel == 4:
                posneg = reviewSubMenu(4)
                ta.analyzingTopics(company_reviews_df, product_reviews_df, posneg)
            elif second_sel == 5:
                ta.analyzingTopics(company_reviews_df, product_reviews_df, 'product')
            elif second_sel == 6:
                ta.analyzingTopics(company_reviews_df, product_reviews_df, 'company')
            elif second_sel == 0:
                sumStats.summary_stats(company_reviews_df, product_reviews_df)
                sumStats.boxplots(company_reviews_df, product_reviews_df)
            else:
                ta.analyzingTopics(company_reviews_df, product_reviews_df, 'all')
    elif selection == 3:
        print()
        while True:
            valid = [1, 2]
            preload_or_not = input("Enter 1 to use preloaded data (HPQ and DELL) or enter 2 to pull live data from"+
                                   " companies of interest **Recommended**: ")
            if int(preload_or_not) in valid:
                break
            else:
                print("Invalid selection. Please enter 1 or 2.")
        if int(preload_or_not) == 2:
            print()
            stock_symbol = input("Please enter the stock symbol for the company or companies you are interested"+
                                 " in separated by a comma. "
                                 "\nNote only US-publicly traded companies are valid (i.e. DELL, HPQ): ")

            symbol_lst = stock_symbol.split(",")
            symbol_lst = [x.strip() for x in symbol_lst]
        else:
            symbol_lst = []

        while True:
            valid = [1, 2, 3]
            metric_input = input("Select metric (TTM) to view on graph:" +
                                 "\n1. Sales per Share" +
                                 "\n2. Total Debt to Equity" +
                                 "\n3. Gross Margin\n"+
                                 'Selection: ')
            try:
                if int(metric_input) in valid:
                    break
                else:
                    print("Invalid selection. Please try again.")
            except:
                print("Invalid selection. Please try again.")

        metric_selected = {1:'salesPerShare', 2: 'totalDebtToEquity', 3:'grossMargin'}
        resp = financials.getMetrics(symbol_lst, metric_selected[int(metric_input)], preload_or_not)
        if resp == "Invalid":
            menuReroute(selection)
        else:
            print("Success! File created.")
            print()

    elif selection == 4:
        print()
        while True:
            valid = [1, 2]
            preload_or_not = input("Enter 1 to use preloaded data (HP, Dell, Lenovo) or enter 2 to pull live data from"+
                                   " companies of interest **Recommended**: ")
            if int(preload_or_not) in valid:
                break
            else:
                print("Invalid selection. Please enter 1 or 2.")
        if int(preload_or_not) == 2:
            companies = input("Please enter the company or companies of interest separated by a comma: ")
            companies = [x.strip() for x in companies.split(",")]
        else:
            companies = []
        resp = news.getNewsInf(companies, int(preload_or_not))
        if resp == "Invalid":
            menuReroute(selection)
        else:
            print("Success! File created.")
            print()
    elif selection == 5:
        print("Creating output... may take a few moments...")
        print()
        product_reviews_df, company_reviews_df = dp.dataLoadPrep()
        df = ta.mergedDF(company_reviews_df, product_reviews_df)
        df.to_csv("ReviewDataOutput.csv")
        print("Output successful!")
    else:
        pass

def scrapeMenu():
    """
    Renders the scraping menu if user selects scraping option
    """
    print()
    print("#################################################################################")
    print()
    print("Please select from choices below (Note: Each will take several hours):")
    print("\t1. Scrape BestBuy")
    print("\t2. Scrape Costco")
    print("\t3. Scrape TrustPilot")
    print("\t4. Scrape ConsumerAffairs")
    print("\t5. Return to Main Menu")
    print()
    print("#################################################################################")
    print()
    while True:
        valid = [1, 2, 3, 4, 5]
        user_select = input("Please enter your selection (1, 2, 3, 4, 5): ")
        if int(user_select) in valid:
            return int(user_select)
        else:
            print("Invalid selection. Please try again.")

def scrapeSubMenu(entry):
    """
    Renders submenu based on selection from the scrapeMenu

    :param entry: User input from scrapeMenu()
    :return:
    """
    if entry == 1:
        site = "BestBuy"
    elif entry == 2:
        site = "Costco"
    elif entry == 3:
        site = "TrustPilot"
    elif entry == 4:
        site = "ConsumerAffairs"
    else:
        site = ""
    print("#################################################################################")
    print()
    print("Please select from choices below to scrape from " + site + ":")
    print("\t1. Scrape Dell")
    print("\t2. Scrape HP")
    print("\t3. Scrape Lenovo")
    print("\t4. Return to Main Menu")
    print()
    print("#################################################################################")
    print()
    while True:
        valid = [1, 2, 3, 4]
        user_select = input("Please enter your selection (1, 2, 3, 4): ")
        if int(user_select) == 4:
            return None, None
        if int(user_select) in valid:
            if int(user_select) == 1:
                company = "Dell"
            elif int(user_select) == 2:
                company = "HP"
            else:
                company = "Lenovo"
            return site, company
        else:
            print("Invalid selection. Please try again.")

def reviewMenu():
    """
    Renders the menu options for viewing options for reviews
    """
    print()
    print("#################################################################################")
    print()
    print("Please select from choices below:")
    print("\t0. View summary statistics for review data")
    print("\t1. See sentiment trends over time by company (plot saved)")
    print("\t2. See sentiment trends over time for all (plot saved)")
    print("\t3. See topics by company")
    print("\t4. See topics by sentiment")
    print("\t5. See topics for product reviews only")
    print("\t6. See topics for company reviews only")
    print("\t7. Compare topics across all companies")
    print("\t8. Return to main menu")
    print()
    print("#################################################################################")
    print()
    while True:
        valid = [0, 1, 2, 3, 4, 5, 6, 7, 8]
        user_select = input("Please enter your selection (0, 1, 2, 3, 4, 5, 6, 7, 8): ")
        if int(user_select) in valid:
            return int(user_select)
        else:
            print("Invalid selection. Please try again.")

def reviewSubMenu(entry):
    """
    Renders review sub menu based on the main selection from the review menu

    :param entry: Input based on reviewMenu selection
    """
    if entry == 1:
        while True:
            valid = ["Dell", "Lenovo", "Hp"]
            user_select = input("Please enter the company to view (Dell, Lenovo, HP): ")
            if user_select.title() in valid:
                if user_select.title() == "Hp":
                    return "HP"
                return user_select.title()
            else:
                print("Invalid selection. Please try again.")
    elif entry == 2:
        while True:
            valid = ["Company", "Product"]
            user_select = input("Please enter which reviews you would like to view trends for (Company, Product): ")
            if user_select.title() in valid:
                return user_select.title()
            else:
                print("Invalid selection. Please try again.")
    elif entry == 3:
        while True:
            valid = ["Dell", "Lenovo", "Hp"]
            user_select = input("Please enter the company to view (Dell, Lenovo, HP): ")
            if user_select.title() in valid:
                return user_select.title()
            else:
                print("Invalid selection. Please try again.")
    elif entry == 4:
        while True:
            valid = ["positive", "negative"]
            user_select = input("Please enter which sentiment reviews you want to view (positive/negative): ")
            if user_select.lower() in valid:
                return user_select.lower()
            else:
                print("Invalid selection. Please try again.")


if __name__ == '__main__':
    while True:
        selection = displayMenu()
        if selection == 0:
            break
        menuReroute(selection)

