"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file pulls from the Google News RSS feed to obtain top news stories for output and word cloud generation.

This file is imported by main.py and imports dfp_project_wordcloud which renders the wordcloud.
"""

import csv
import feedparser
import pandas as pd
import dfp_project_wordcloud as wordcloud

def getNewsInf(queries, preloaded):
    """
    Connects to Google News RSS feed to pull relevant information

    :param queries: List containing companies of interest
    :return: CSV file containing top news stories for companies of interest
    """
    with open("GoogleNews.csv", "w", newline = "", encoding='utf-8') as outfile:
        if preloaded == 2:
            writer = csv.DictWriter(outfile, fieldnames=['Company', 'Title', 'Link', 'Source',
                                                            'Year', 'Month', 'Day', 'Summary'])
            writer.writeheader()

            for q in queries:
                url = "https://news.google.com/rss/search?q="+q+"&hl=en-US&gl=US&ceid=US:en"
                response = feedparser.parse(url)
                if len(response['entries']) == 0:
                    print("Sorry! No articles found.")
                    print()
                    return "Invalid"
                for article in response['entries']:
                    d = {}
                    title = article['title']
                    summary = article['title_detail']['value']
                    link = article['link']
                    source = article['source']['title']
                    year = article['published_parsed'].tm_year
                    month = article['published_parsed'].tm_mon
                    day = article['published_parsed'].tm_mday

                    d['Company'] = q
                    d['Title'] = title
                    d['Year'] = year
                    d['Month'] = month
                    d['Day'] = day
                    d['Summary'] = summary
                    d['Link'] = link
                    d['Source'] = source

                    writer.writerow(d)
        else:
            df = pd.read_csv("GoogleNews_DellLenovoHP.csv")
            df.to_csv("GoogleNews.csv")

    wordcloud.wordcloud_generator('GoogleNews.csv')


    print("Word cloud and CSV created!")
    return "Success"


