"""
Group Members:
Susan Doong
Steffi Nazareth
Simran Bhalla
Saurabh Pethe

This is file scrapes Costco.com

This file is imported by main.py
"""

from bs4 import BeautifulSoup
from selenium import webdriver
import csv
import time

DRIVER_PATH = 'chromedriver.exe'
BASE_URL = 'https://www.bestbuy.com'
options = webdriver.ChromeOptions()
options.add_argument('--ignore-certificate-errors')
options.add_argument('--ignore-ssl-errors')
options.add_argument('--ignore-certificate-errors-spki-list')

def getData(URL):
    """
    :param URL: URL of site to scrape
    :return: html of site
    """
    driver = webdriver.Chrome(executable_path=DRIVER_PATH, options=options)
    driver.get(URL)
    html = BeautifulSoup(driver.page_source, "html.parser")
    driver.close()
    return html

def scrapeCostco(company):
    """
    Scrapes Costco.com for company of interest

    :param company: Company to scrape
    :return: CSV file of scraped data
    """
    if company == "HP":
        URL = "https://www.costco.com/CatalogSearch?dept=All&keyword=hp+laptops"
    elif company == "Dell":
        URL = "https://www.costco.com/CatalogSearch?dept=All&keyword=Dell+laptops"
    else:
        URL = "https://www.costco.com/CatalogSearch?dept=All&keyword=Lenovo+laptops"

    html = getData(URL)
    counter = 0

    csv_name = "Updated_CostcoReviews_" + company + ".csv"
    with open(csv_name, "w", newline="") as outfile:
        writer = csv.DictWriter(outfile, fieldnames=["Product_Title", "Price", "ProductURL",
                                                     "Rating", "Date_Posted",
                                                     "Review_Content"])
        writer.writeheader()

        ### Extracts product URLs and clicks into the product page to scrape reviews
        for prod in html.find_all("div", {"class":"thumbnail"}):
            try:
                prod_url = prod.find("p", {"class":"description"}).find("a", href = True)['href']
            except:
                continue
            if "www.costco.com/" not in prod_url:
                continue
            print(prod_url)
            driver2 = webdriver.Chrome(executable_path=DRIVER_PATH, options=options)
            driver2.get(prod_url)
            button_element = driver2.find_element_by_xpath('//*[@id="nav-pdp-tab-header-12"]/div[2]/div/input')

            ### Mimics human and gives time for page to load
            time.sleep(25)
            try:
                button_element.click()
            except:
                continue

            prod_html = BeautifulSoup(driver2.page_source, 'html.parser')
            prod_name = prod_html.find("h1", {"itemprop":"name"}).text
            price = prod_html.find("div", {"id":"pull-right-price"}).find("span", {"class":"value"}).text
            review_count = int(prod_html.find("span", {"itemprop":"reviewCount"}).text)
            rev_count = 0

            next_page_flag = True
            while next_page_flag:
                for p in prod_html.find_all("ol", {"class":"bv-content-list bv-content-list-reviews"}):
                    for prod_rev in p.find_all("div", {"class":"bv-content-container"}):
                        d = {}
                        try:
                            rating = prod_rev.find("span", {"class":"bv-off-screen"}).text.split()[0]
                        except:
                            rating = ""

                        try:
                            date = prod_rev.find("meta", {"itemprop":"datePublished"})["content"]
                        except:
                            date = ""

                        try:
                            content = prod_rev.find("div", {"class":"bv-content-summary-body-text"}).text
                        except:
                            content = ""
                        d['Product_Title'] = prod_name
                        d['Price'] = price
                        d['ProductURL'] = prod_url
                        d['Rating'] = rating
                        d['Date_Posted'] = date
                        d['Review_Content'] = content
                        try:
                            writer.writerow(d)
                        except:
                            pass
                        print("Total: ", counter)
                        print("Product Counter: ", rev_count)
                        counter += 1
                        rev_count += 1
                ### Continue to click next page until all reviews are scraped
                if rev_count <= review_count:
                    try:
                        next_page = driver2.find_element_by_xpath('//*[@id="BVRRContainer"]/div/div/div/div/div[3]/div/ul/li[2]')
                        next_page.click()
                        time.sleep(5)
                        prod_html = BeautifulSoup(driver2.page_source, 'html.parser')
                    except:
                        driver2.close()
                        break
                else:
                    print("FALSE")
                    driver2.close()
                    break

